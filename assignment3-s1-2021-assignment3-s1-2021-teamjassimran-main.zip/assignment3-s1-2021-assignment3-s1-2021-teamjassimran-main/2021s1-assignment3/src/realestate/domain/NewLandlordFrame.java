package realestate.domain;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

public class NewLandlordFrame extends JFrame{
	public NewLandlordFrame() {		
		setLayout (new BorderLayout());		
		JPanel top=new JPanel();
		JLabel title=new JLabel("New Landlord",SwingConstants.CENTER);
		title.setFont(new Font("TimesRoman", Font.PLAIN, 32));
		top.add(title);
		JPanel form=new JPanel();
		//adding labels
		JLabel nameLabel, addressLabel,uniqueIDLabel,bankDetailsLabel,weeklyRentLabel;
		JLabel messageLabel=new JLabel(" ");
		nameLabel=new JLabel("Name");
		addressLabel=new JLabel("Address");
		uniqueIDLabel=new JLabel("ID");
		bankDetailsLabel=new JLabel("Bank");
		weeklyRentLabel=new JLabel("Weeky Rent");
		//adding text boxes
		JTextField nameTxt,addressTxt,idTxt,bankdetailsTxt,weeklyRentTxt;
		nameTxt=new JTextField(10);
		addressTxt=new JTextField(20);
		idTxt=new JTextField(5);
		bankdetailsTxt=new JTextField(10);
		weeklyRentTxt=new JTextField(10);
		JButton save=new JButton("Save");
		//adding to label
		form.add(messageLabel);
		form.add(nameLabel);
		form.add(nameTxt);
		form.add(addressLabel);
		form.add(addressTxt);
		form.add(uniqueIDLabel);
		form.add(idTxt);
		form.add(bankDetailsLabel);
		form.add(bankdetailsTxt);
		form.add(weeklyRentLabel);
		form.add(weeklyRentTxt);
		form.add(messageLabel);
		form.add(save);
		
		
		save.addActionListener(new ActionListener(){  
			public void actionPerformed(ActionEvent e){ 
				try {
				String name=nameTxt.getText();
				String address=addressTxt.getText();
				int id=Integer.parseInt(idTxt.getText());
				String bankdetail= bankdetailsTxt.getText();
				double weeklyRent=Double.parseDouble(weeklyRentTxt.getText());
				if(name.length()<=0) {
					messageLabel.setText("Please enter name!");
					return;
				}
				if(address.length()<=0) {
					messageLabel.setText("Please enter address!");
					return;
				}
				if(bankdetail.length()<=0) {
					messageLabel.setText("Please enter bank details!");
					return;
				}
				if(weeklyRent<=0) {
					messageLabel.setText("Please enter value weekly rent amount!");
					return;
				}
				
				for(Owner owner:RealEstateRecordsSystem.owners) {
					if(owner.getOwnerID()==id) {
						messageLabel.setText("Please enter unique id for owner!");
						return;
					}
				}
				
			
				
				Landlord landlord=new Landlord(name, address, id, bankdetail, weeklyRent);
				RealEstateRecordsSystem.owners.add(landlord);
				messageLabel.setText("Landlord details saved!");
				nameTxt.setText("");
				addressTxt.setText("");
				bankdetailsTxt.setText("");
				idTxt.setText("");
				weeklyRentTxt.setText("");
				
				
				
				}catch(NumberFormatException ex) {
					messageLabel.setText("Invalid data type used!");
				}catch(Exception ex) {
					messageLabel.setText("Error occured while saving the record");
				}
		}  
		});
		form.setLayout(new FlowLayout(FlowLayout.CENTER,200,10));
		this.add(top,BorderLayout.NORTH);
		this.add(form,BorderLayout.CENTER);
		setTitle("New Landlord");
		setSize(300,470); 
		setLocationRelativeTo(null);
		setVisible(true);  
	}
}
