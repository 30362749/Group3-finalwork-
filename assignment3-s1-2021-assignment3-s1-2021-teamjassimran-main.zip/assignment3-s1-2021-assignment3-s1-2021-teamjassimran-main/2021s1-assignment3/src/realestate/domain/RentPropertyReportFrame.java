package realestate.domain;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileWriter;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

public class RentPropertyReportFrame extends JFrame {
	public RentPropertyReportFrame() {
		setLayout (new BorderLayout());		
		JPanel top=new JPanel();
		JLabel title=new JLabel("Rental property Report",SwingConstants.CENTER);
		title.setFont(new Font("TimesRoman", Font.PLAIN, 32));
		top.add(title);
		JPanel form=new JPanel();
		//adding labels
		JLabel townLabel, filenameLabel;
		JLabel messageLabel=new JLabel(" ");
		townLabel=new JLabel("Town");
		filenameLabel=new JLabel("File Name");
		//adding text boxes
		JTextField townTxt,filenameTxt;
		townTxt=new JTextField(10);
		filenameTxt=new JTextField(10);

		JButton report=new JButton("Generate Report");
		//adding to label
		form.add(townLabel);
		form.add(townTxt);
		form.add(filenameLabel);
		form.add(filenameTxt);
		form.add(report);
		form.add(messageLabel);
		
		
		
		report.addActionListener(new ActionListener(){  
			public void actionPerformed(ActionEvent e){  
				try {
				String town=townTxt.getText().toString();
				String file=filenameTxt.getText().toString();
				if(town.length()<=0) {
					messageLabel.setText("Please enter town!");
					return;
				}
				if(file.length()<=0) {
					messageLabel.setText("Please enter filename!");
					return;
				}
				
				 File f = new File(file);
			        if (f.exists()) {
			        	messageLabel.setText("File aready exists");
			        	return;
			        	
			        }
			        else {
			        	FileWriter myWriter = new FileWriter(file);
			        	myWriter.write(String.format("%-50s%-20s%-20s%-10s%-20s","Address","Tenant Name","Tenanat Phone","Rent","Owner Name")+"\n");
			        	for(RentalProperty rentalProperty:RealEstateRecordsSystem.getRentalProperties()) {
			        		if(rentalProperty.getTown().equalsIgnoreCase(town)) {
				        		Landlord owner=(Landlord)rentalProperty.getPropertyOwner();
				        		myWriter.write(String.format("%-50s%-20s%-20s%-10s%-20s",rentalProperty.getAddress(),rentalProperty.getTenantName(),rentalProperty.getTenantPhone(),owner.getWeeklyRent(),owner.getName())+"\n");
				        	}
			        	}	
			        	myWriter.flush();
			        	myWriter.close();
			        	messageLabel.setText("Report create File:"+file);
			        	
			        }
			        
				}catch(Exception error) {
					messageLabel.setText("Error occured while writing the file!");
				}
			 
			}  
		});
		
		form.setLayout(new FlowLayout(FlowLayout.CENTER,200,10));
		this.add(top,BorderLayout.NORTH);
		this.add(form,BorderLayout.CENTER);
		setTitle("New Seller");
		setSize(330,400); 
		setLocationRelativeTo(null);
		setVisible(true);  
	}
}
