package realestate.domain;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

public class NewSellerFrame extends JFrame {
	public NewSellerFrame() {
		setLayout (new BorderLayout());		
		JPanel top=new JPanel();
		JLabel title=new JLabel("New Seller",SwingConstants.CENTER);
		title.setFont(new Font("TimesRoman", Font.PLAIN, 32));
		top.add(title);
		JPanel form=new JPanel();
		//adding labels	
		JLabel nameLabel, addressLabel,uniqueIDLabel,conveyancerLabel;
		JLabel messageLabel=new JLabel(" ");
		nameLabel=new JLabel("Name");
		addressLabel=new JLabel("Address");
		uniqueIDLabel=new JLabel("ID");
		conveyancerLabel=new JLabel("Conveyancer");
		//adding text boxes
		JTextField nameTxt,addressTxt,idTxt,conveyancerTxt;
		nameTxt=new JTextField(10);
		addressTxt=new JTextField(20);
		idTxt=new JTextField(5);
		conveyancerTxt=new JTextField(10);
		JButton save=new JButton("Save");
		//adding to label
		form.add(nameLabel);
		form.add(nameTxt);
		form.add(addressLabel);
		form.add(addressTxt);
		form.add(uniqueIDLabel);
		form.add(idTxt);
		form.add(conveyancerLabel);		
		form.add(conveyancerTxt);
		form.add(messageLabel);
		form.add(save);
		
		save.addActionListener(new ActionListener(){  
			public void actionPerformed(ActionEvent e){ 
				try {
				String name=nameTxt.getText();
				String address=addressTxt.getText();
				int id=Integer.parseInt(idTxt.getText());
				String conveyancer= conveyancerTxt.getText();
				if(name.length()<=0) {
					messageLabel.setText("Please enter name!");
					return;
				}
				if(address.length()<=0) {
					messageLabel.setText("Please enter address!");
					return;
				}
				if(conveyancer.length()<=0) {
					messageLabel.setText("Please enter conveyancer name!");
					return;
				}
				
				for(Owner owner:RealEstateRecordsSystem.owners) {
					if(owner.getOwnerID()==id) {
						messageLabel.setText("Please enter unique id for owner!");
						return;
					}
				}
				
				Seller seller=new Seller(name, address, id, conveyancer);
				RealEstateRecordsSystem.owners.add(seller);
				messageLabel.setText("Seller details saved!");
				nameTxt.setText("");
				addressTxt.setText("");
				conveyancerTxt.setText("");
				idTxt.setText("");
				
				
				
				}catch(NumberFormatException ex) {
					messageLabel.setText("Invalid data type used!");
				}catch(Exception ex) {
					messageLabel.setText("Error occured while saving the record");
				}
		}  
		});
		
		
		
		form.setLayout(new FlowLayout(FlowLayout.CENTER,200,10));
		this.add(top,BorderLayout.NORTH);
		this.add(form,BorderLayout.CENTER);
		setTitle("New Seller");
		setSize(300,450); 
		setLocationRelativeTo(null);
		setVisible(true);  
		
	}
}
