package realestate.domain;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.SwingConstants;

public class MainMenu  extends JFrame { 
	public MainMenu() {
		//heading
		JLabel title=new JLabel("Real Estate Records",SwingConstants.CENTER);
		title.setFont(new Font("TimesRoman", Font.PLAIN, 32));
		//different button for different options
		JButton resetData=new JButton("Reset Data");
		JButton newSeller=new JButton("Add New Seller");
		JButton newLandlord=new JButton("Add New Landlord");
		JButton newRentProperty=new JButton("Add New Rent Property");
		JButton newSaleProperty=new JButton("Add new Sale Property");
		JButton saleReport=new JButton("Sale property report");
		JButton rentReport=new JButton("Rent property report");
		JButton close=new JButton("Close");
		close.setBackground(Color.RED);
		close.setForeground(Color.WHITE);
		this.add(title);
		this.add(resetData);
		this.add(newSeller);
		this.add(newLandlord);
		this.add(newRentProperty);
		this.add(newSaleProperty);
		this.add(saleReport);
		this.add(rentReport);
		this.add(close);
		setLayout (new FlowLayout(FlowLayout.CENTER,200,10));  
		
		
		newLandlord.addActionListener(new ActionListener(){  
			public void actionPerformed(ActionEvent e){  
		          new NewLandlordFrame();
		}  
		}); 
		
		newSeller.addActionListener(new ActionListener(){  
			public void actionPerformed(ActionEvent e){  
		          new NewSellerFrame();
		}  
		}); 
		
		newRentProperty.addActionListener(new ActionListener(){  
			public void actionPerformed(ActionEvent e){  
		          new NewRentPropertyFrame();
		}  
		});
		
		newSaleProperty.addActionListener(new ActionListener(){  
			public void actionPerformed(ActionEvent e){  
		          new NewSalePropertyFrame();
		}  
		});
		
		
		resetData.addActionListener(new ActionListener(){  
			public void actionPerformed(ActionEvent e){  
		          RealEstateRecordsSystem.loadOwnerData();
		          RealEstateRecordsSystem.loadSellerData();
		}  
		});
		
		saleReport.addActionListener(new ActionListener(){  
			public void actionPerformed(ActionEvent e){  
		          new SalePropertyReportFrame();
		}  
		});
		
		rentReport.addActionListener(new ActionListener(){  
			public void actionPerformed(ActionEvent e){  
		          new RentPropertyReportFrame();
		}  
		});
		this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		this.addWindowListener(new WindowAdapter()
	        {
	            @Override
	            public void windowClosing(WindowEvent e)
	            {
	            	//saving data before closing
	                RealEstateRecordsSystem.writeOwnersToSerializedFile();
	                RealEstateRecordsSystem.writePropertiesToSerializedFile();
	                System.exit(0);
	            }
	        });
		
		close.addActionListener(new ActionListener(){  
			public void actionPerformed(ActionEvent e){  
				//saving data before closing
				 RealEstateRecordsSystem.writeOwnersToSerializedFile();
	             RealEstateRecordsSystem.writePropertiesToSerializedFile();
	             System.exit(0);
		}  
		});
		setSize(300,400); 
		setTitle("Main Menu");
		setLocationRelativeTo(null);
		setVisible(true);  
		
	}
}
