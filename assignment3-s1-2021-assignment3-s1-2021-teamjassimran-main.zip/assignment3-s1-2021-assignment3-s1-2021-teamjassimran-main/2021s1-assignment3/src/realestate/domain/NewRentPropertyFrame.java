package realestate.domain;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

public class NewRentPropertyFrame extends JFrame {

	public NewRentPropertyFrame() {
		setLayout (new BorderLayout());		
		JPanel top=new JPanel();
		JLabel title=new JLabel("New Rental Property",SwingConstants.CENTER);
		title.setFont(new Font("TimesRoman", Font.PLAIN, 30));
		top.add(title);
		JPanel form=new JPanel();
		//adding labels	
		JLabel addressLabel, townLabel,uniqueIDLabel,ownerLabel,tenantLabel,tenantPhoneLabel;
		JLabel messageLabel=new JLabel(" ");
		addressLabel=new JLabel("Address");
		townLabel=new JLabel("Town");
		uniqueIDLabel=new JLabel("ID");
		ownerLabel=new JLabel("Owner");
		tenantLabel=new JLabel("Tenant Name");
		tenantPhoneLabel=new JLabel("Tenant Phone");
		//adding text boxes
		JTextField townTxt,addressTxt,idTxt,tenantTxt,tenantPhoneTxt;
		townTxt=new JTextField(10);
		addressTxt=new JTextField(20);
		idTxt=new JTextField(5);
		tenantTxt=new JTextField(10);
		tenantPhoneTxt=new JTextField(10);
		JComboBox ownersList=new JComboBox();
		for(Landlord landlord:RealEstateRecordsSystem.getLandlords()) {
			ownersList.addItem("ID:"+landlord.getOwnerID()+" Name:"+landlord.getName());
		}
		
		
		JButton save=new JButton("Save");
		//adding to label
		form.add(townLabel);
		form.add(townTxt);
		form.add(addressLabel);
		form.add(addressTxt);
		form.add(uniqueIDLabel);
		form.add(idTxt);
		form.add(ownerLabel);		
		form.add(ownersList);
		form.add(tenantLabel);	
		form.add(tenantTxt);	
		form.add(tenantPhoneLabel);	
		form.add(tenantPhoneTxt);	
		form.add(messageLabel);
		form.add(save);
		
		save.addActionListener(new ActionListener(){  
			public void actionPerformed(ActionEvent e){ 
				try {
				String town=townTxt.getText();
				String address=addressTxt.getText();
				int id=Integer.parseInt(idTxt.getText());
				String tenant= tenantTxt.getText();
				String tenantPhone=tenantPhoneTxt.getText();
				if(town.length()<=0) {
					messageLabel.setText("Please enter town!");
					return;
				}
				if(address.length()<=0) {
					messageLabel.setText("Please enter address!");
					return;
				}
				if(tenant.length()<=0) {
					messageLabel.setText("Please enter tenant name!");
					return;
				}
				if(tenantPhone.length()<=0) {
					messageLabel.setText("Please enter tenant phone number!");
					return;
				}
				
				Owner owner=RealEstateRecordsSystem.getLandlords().get(ownersList.getSelectedIndex());
				for(Property property:RealEstateRecordsSystem.properties) {
					if(property.getPropertyID()==id) {
						messageLabel.setText("Please enter unique id for property!");
						return;
					}
				}
				
				
				RentalProperty rentProperty=new RentalProperty(address,town, id, owner,tenant, tenantPhone);
				
				RealEstateRecordsSystem.properties.add(rentProperty);
				messageLabel.setText("Rental property details saved!");
				townTxt.setText("");
				addressTxt.setText("");
				tenantTxt.setText("");
				idTxt.setText("");
				tenantPhoneTxt.setText("");
								
				}catch(NumberFormatException ex) {
					messageLabel.setText("Invalid data type used!");
				}catch(Exception ex) {
					messageLabel.setText("Error occured while saving the record");
				}
		}  
		});
		
		
		form.setLayout(new FlowLayout(FlowLayout.CENTER,200,10));
		this.add(top,BorderLayout.NORTH);
		this.add(form,BorderLayout.CENTER);
		setTitle("New Rental Property");
		setSize(300,500); 
		setLocationRelativeTo(null);
		setVisible(true); 
		
	}
}
