package realestate.domain;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileWriter;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

public class SalePropertyReportFrame extends JFrame {
	
	public SalePropertyReportFrame() {
		setLayout (new BorderLayout());		
		JPanel top=new JPanel();
		JLabel title=new JLabel("Sales property Report",SwingConstants.CENTER);
		title.setFont(new Font("TimesRoman", Font.PLAIN, 32));
		top.add(title);
		JPanel form=new JPanel();
		//adding labels
		JLabel amountLabel, filenameLabel;
		JLabel messageLabel=new JLabel(" ");
		amountLabel=new JLabel("Min Amount");
		filenameLabel=new JLabel("File Name");
		//adding text boxes
		JTextField amountTxt,filenameTxt;
		amountTxt=new JTextField(10);
		filenameTxt=new JTextField(10);

		JButton report=new JButton("Generate Report");
		//adding to label
		form.add(amountLabel);
		form.add(amountTxt);
		form.add(filenameLabel);
		form.add(filenameTxt);
		form.add(messageLabel);
		form.add(report);
		report.addActionListener(new ActionListener(){  
			public void actionPerformed(ActionEvent e){  
				try {
				double amount=Double.parseDouble(amountTxt.getText().toString());
				String file=filenameTxt.getText().toString();
				if(amount<=0) {
					messageLabel.setText("Please enter valid amount!");
					return;
				}
				if(file.length()<=0) {
					messageLabel.setText("Please enter filename!");
					return;
				}
				
				 File f = new File(file);
			        if (f.exists()) {
			        	messageLabel.setText("File aready exists");
			        	return;
			        	
			        }
			        else {
			        	FileWriter myWriter = new FileWriter(file);
			        	myWriter.write(String.format("%-50s%-20s%-20s%-10s%-10s","Address","Town","Owner Name","Indoor Area","Asking Price")+"\n");
			        	for(SaleProperty saleProperty:RealEstateRecordsSystem.getSaleProperties()) {
			        		if(saleProperty.getPrice()>=amount) {
				        		myWriter.write(String.format("%-50s%-20s%-20s%-10s%-20s",saleProperty.getAddress(),saleProperty.getTown(),saleProperty.getPropertyOwner().getName(),saleProperty.getIndoorArea(),saleProperty.getPrice())+"\n");
				        	}
			        	}	
			        	myWriter.flush();
			        	myWriter.close();
			        	messageLabel.setText("Report create File:"+file);
			        	
			        }
			        
				}catch(Exception error) {
					messageLabel.setText("Error occured while writing the file!");
				}
			 
			}  
		});
		
		form.setLayout(new FlowLayout(FlowLayout.CENTER,200,10));
		this.add(top,BorderLayout.NORTH);
		this.add(form,BorderLayout.CENTER);
		setTitle("New Seller");
		setSize(300,400); 
		setLocationRelativeTo(null);
		setVisible(true);  
	}
}
