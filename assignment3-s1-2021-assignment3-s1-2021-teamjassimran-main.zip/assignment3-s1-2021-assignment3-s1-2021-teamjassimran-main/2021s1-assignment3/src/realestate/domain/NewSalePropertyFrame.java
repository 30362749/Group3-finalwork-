package realestate.domain;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

public class NewSalePropertyFrame extends JFrame{
	public NewSalePropertyFrame() {
		
		setLayout (new BorderLayout());		
		JPanel top=new JPanel();
		JLabel title=new JLabel("New Sale Property",SwingConstants.CENTER);
		title.setFont(new Font("TimesRoman", Font.PLAIN, 32));
		top.add(title);
		JPanel form=new JPanel();
		//adding labels	
		JLabel addressLabel, townLabel,uniqueIDLabel,ownerLabel,askingPriceLabel,indoorAreaLabel;
		JLabel messageLabel=new JLabel(" ");
		addressLabel=new JLabel("Address");
		townLabel=new JLabel("Town");
		uniqueIDLabel=new JLabel("ID");
		ownerLabel=new JLabel("Owner");
		askingPriceLabel=new JLabel("Asking Price");
		indoorAreaLabel=new JLabel("Indoor Area");
		//adding text boxes
		JTextField townTxt,addressTxt,idTxt,askingPriceTxt,indoorAreaTxt;
		townTxt=new JTextField(10);
		addressTxt=new JTextField(20);
		idTxt=new JTextField(5);
		askingPriceTxt=new JTextField(10);
		indoorAreaTxt=new JTextField(10);
		JComboBox ownersList=new JComboBox();
		for(Seller seller:RealEstateRecordsSystem.getSellers()) {
			ownersList.addItem("ID:"+seller.getOwnerID()+" Name:"+seller.getName());
		}
		
		
		JButton save=new JButton("Save");
		//adding to label
		form.add(townLabel);
		form.add(townTxt);
		form.add(addressLabel);
		form.add(addressTxt);
		form.add(uniqueIDLabel);
		form.add(idTxt);
		form.add(ownerLabel);		
		form.add(ownersList);
		form.add(askingPriceLabel);	
		form.add(askingPriceTxt);	
		form.add(indoorAreaLabel);	
		form.add(indoorAreaTxt);	
		form.add(messageLabel);			
		form.add(save);
		
		save.addActionListener(new ActionListener(){  
			public void actionPerformed(ActionEvent e){ 
				try {
				String town=townTxt.getText();
				String address=addressTxt.getText();
				int id=Integer.parseInt(idTxt.getText());
				int askingPrice= Integer.parseInt(askingPriceTxt.getText());
				double indoorArea=Double.parseDouble(indoorAreaTxt.getText());
				if(town.length()<=0) {
					messageLabel.setText("Please enter town!");
					return;
				}
				if(address.length()<=0) {
					messageLabel.setText("Please enter address!");
					return;
				}
				if(askingPrice<=0) {
					messageLabel.setText("Please enter valid asking price!");
					return;
				}
				if(indoorArea<=0) {
					messageLabel.setText("Please enter valid indoor area!");
					return;
				}
				
				for(Property property:RealEstateRecordsSystem.properties) {
					if(property.getPropertyID()==id) {
						messageLabel.setText("Please enter unique id for property!");
						return;
					}
				}
				
				Owner owner=RealEstateRecordsSystem.getSellers().get(ownersList.getSelectedIndex());
				
				SaleProperty saleProperty=new SaleProperty(address,town, id, owner,askingPrice, indoorArea);
				
				RealEstateRecordsSystem.properties.add(saleProperty);
				messageLabel.setText("Sale property details saved!");
				townTxt.setText("");
				addressTxt.setText("");
				askingPriceTxt.setText("");
				idTxt.setText("");
				indoorAreaTxt.setText("");								
				}catch(NumberFormatException ex) {
					messageLabel.setText("Invalid data type used!");
				}catch(Exception ex) {
					messageLabel.setText("Error occured while saving the record"+ex.toString());
				}
		}  
		});
		
		
		
		form.setLayout(new FlowLayout(FlowLayout.CENTER,200,10));
		this.add(top,BorderLayout.NORTH);
		this.add(form,BorderLayout.CENTER);
		setTitle("New Sale Property");
		setSize(300,500); 
		setLocationRelativeTo(null);
		setVisible(true); 
		
	}
}
