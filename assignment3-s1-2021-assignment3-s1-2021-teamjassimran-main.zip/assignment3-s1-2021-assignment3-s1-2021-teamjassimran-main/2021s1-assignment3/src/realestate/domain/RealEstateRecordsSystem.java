package realestate.domain;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

public class RealEstateRecordsSystem {
	//to store list of properties and owners
	public static ArrayList<Owner> owners;
	public static ArrayList<Property> properties;
	public static void main(String[] args) {
		owners=new ArrayList<Owner>();
		properties=new ArrayList<Property>();
		// TODO Auto-generated method stub
		loadOwnerData();
		loadSellerData();
		System.out.println(properties.size());
		//to check if file exist then load from ser file
	    File f = new File("owners.ser");
        if (f.exists()) {
        	readOwnersFromSerializedFile();
        }
        else {
        	writeOwnersToSerializedFile();
        }
        //to check if file exist then load from ser file
        f = new File("properties.ser");
        if (f.exists()) {
        	readPropertiesFromSerializedFile();
        }
        else {
        	writePropertiesToSerializedFile();
        }
		new MainMenu();
		
	}
	
	
	/*
	 * To add owners from default csv file
	 * */
	public static void loadOwnerData() {
		owners.clear();
		try   
		{  
			String line="";
			BufferedReader br = new BufferedReader(new FileReader("owners.csv"));  
			while ((line = br.readLine()) != null)   //returns a Boolean value  
			{  
				String[] data = line.split(",");    // use comma as separator  
				if(data.length>=5) {
					int ownerType=Integer.parseInt(data[3]);
					//seller
					if(ownerType==1) {
						String name=data[0];
						String address=data[1];
						int uniqueID=Integer.parseInt(data[2]);
						String conveyancer=data[4];
						Seller seller=new Seller(name,address,uniqueID,conveyancer);
						owners.add(seller);
					}//owner
					else if(ownerType==2) {
						String name=data[0];
						String address=data[1];
						int uniqueID=Integer.parseInt(data[2]);
						String bankDetails=data[4];
						double weeklyRent=Double.parseDouble(data[5]);
						Landlord landlord=new Landlord(name,address,uniqueID,bankDetails,weeklyRent);
						owners.add(landlord);
					}
					
				}
			}  
		}   
		catch (IOException error)   
		{  
			System.out.println("Error reading the csv file:\n"+error.toString());			
		}  
		catch (NumberFormatException error) {
			System.out.println("Error while processing data input:\n"+error.toString());	
		}
		
	}
	/*
	 * To add sellers from default csv file
	 * */
	public static void loadSellerData() {
		properties.clear();
		try   
		{  
			String line="";
			BufferedReader br = new BufferedReader(new FileReader("properties.csv"));  
			while ((line = br.readLine()) != null)   //returns a Boolean value  
			{  
				String[] data = line.split(",");    // use comma as separator  
				if(data.length==7) {
					int propertyType=Integer.parseInt(data[4]);
					//sale property
					if(propertyType==1) {
						String address=data[0];
						String town=data[1];
						int propertyID=Integer.parseInt(data[2]);
						int ownerId=Integer.parseInt(data[3]);
						Owner propertyOwner=null;
						//to find owner by id
						for(Owner owner:owners) {
							if(owner.getOwnerID()==ownerId) {
								propertyOwner=owner;
							}
						}
						int askingPrice=Integer.parseInt(data[5]);
						double indoorArea=Double.parseDouble(data[6]);
						//if owner found adding property record else not
						if(propertyOwner!=null) {
							SaleProperty saleProperty=new SaleProperty(address,town, propertyID, propertyOwner,askingPrice, indoorArea);
							properties.add(saleProperty);
						}
					
					}//rent property
					else if(propertyType==2) {
						String address=data[0];
						String town=data[1];
						int propertyID=Integer.parseInt(data[2]);
						int ownerId=Integer.parseInt(data[3]);
						
						Owner propertyOwner=null;
						//to find owner by id
						for(Owner owner:owners) {
							if(owner.getOwnerID()==ownerId) {
								propertyOwner=owner;								
							}
						}
						String tenantName=data[5];
						String tenantPhone=data[6];
						//if owner found adding property record else not
						if(propertyOwner!=null) {
							RentalProperty rentalProperty=new RentalProperty(address,town,propertyID,propertyOwner,tenantName,tenantPhone);
							properties.add(rentalProperty);
						}
					}
					
				}
			}  
		}   
		catch (IOException error)   
		{  
			System.out.println("Error reading the csv file:\n"+error.toString());			
		}  
		catch (NumberFormatException error) {
			System.out.println("Error while processing data input:\n"+error.toString());	
		}
	}

	
	/*
	 * To get all landlord records only
	 * */
	public static ArrayList<Landlord> getLandlords(){
		ArrayList<Landlord> landlords=new ArrayList<Landlord>();
		for(Owner owner:owners) {
			if(owner instanceof Landlord)
			{
				Landlord landlord=(Landlord)owner;
				landlords.add(landlord);
			}
		}
		return landlords;
	}
	
	
	/*
	 * To get all seller records only
	 * */
	public static ArrayList<Seller> getSellers(){
		ArrayList<Seller> sellers=new ArrayList<Seller>();
		for(Owner owner:owners) {
			if(owner instanceof Seller)
			{
				Seller seller=(Seller)owner;
				sellers.add(seller);
			}
		}
		return sellers;
	}
	
	
	/*
	 * To get all rental properties records only
	 * */
	public static ArrayList<RentalProperty> getRentalProperties(){
		ArrayList<RentalProperty> rentalProperties=new ArrayList<RentalProperty>();
		for(Property property:properties) {
			if(property instanceof RentalProperty)
			{
				RentalProperty rentalProperty=(RentalProperty)property;
				rentalProperties.add(rentalProperty);
			}
		}
		return rentalProperties;
	}
	
	
	/*
	 * To get all sale properties records only
	 * */
	public static ArrayList<SaleProperty> getSaleProperties(){
		ArrayList<SaleProperty> salesProperties=new ArrayList<SaleProperty>();
		for(Property property:properties) {
			if(property instanceof SaleProperty)
			{
				SaleProperty saleProperty=(SaleProperty)property;
				salesProperties.add(saleProperty);
			}
		}
		return salesProperties;
	}
	
	
	/*
	 * To write updated owner data to serialized file
	 * */
	public static void writeOwnersToSerializedFile() {
		ObjectOutputStream oos = null;
		FileOutputStream fout = null;
		try{
		    fout = new FileOutputStream("owners.ser");
		    oos = new ObjectOutputStream(fout);
		    oos.writeObject(owners);
		} catch (Exception ex) {
		    ex.printStackTrace();
		} finally {
		    if(oos != null){
		        try {
					oos.close();
				} catch (IOException error) {
					// TODO Auto-generated catch block
					System.out.println("Error while writing data:\n"+error.toString());	
				}
		    } 
		}
	}
	/*
	 * To read updated owner data from serialized file
	 * */
	public static void readOwnersFromSerializedFile() {
		owners.clear();
		ObjectInputStream objectinputstream = null;
		try {
		    FileInputStream streamIn = new FileInputStream("owners.ser");
		    objectinputstream = new ObjectInputStream(streamIn);
		    owners = (ArrayList<Owner>) objectinputstream.readObject();
		   
		} catch (Exception e) {
		    e.printStackTrace();
		} 
	}
	
	
	/*
	 * To write updated properties data to serialized file
	 * */
	public static void writePropertiesToSerializedFile() {
		ObjectOutputStream oos = null;
		FileOutputStream fout = null;
		try{
		    fout = new FileOutputStream("properties.ser");
		    oos = new ObjectOutputStream(fout);
		    oos.writeObject(properties);
		} catch (Exception ex) {
		    ex.printStackTrace();
		} finally {
		    if(oos != null){
		        try {
					oos.close();
				} catch (IOException error) {
					// TODO Auto-generated catch block
					System.out.println("Error while writing data:\n"+error.toString());	
				}
		    } 
		}
	}
	/*
	 * To read updated properties data from serialized file
	 * */
	public static void readPropertiesFromSerializedFile() {
		properties.clear();
		ObjectInputStream objectinputstream = null;
		try {
		    FileInputStream streamIn = new FileInputStream("properties.ser");
		    objectinputstream = new ObjectInputStream(streamIn);
		    properties = (ArrayList<Property>) objectinputstream.readObject();
		   
		} catch (Exception e) {
		    e.printStackTrace();
		} 
	}	
}
