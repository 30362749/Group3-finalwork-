module assign3 {
	requires java.desktop;
}