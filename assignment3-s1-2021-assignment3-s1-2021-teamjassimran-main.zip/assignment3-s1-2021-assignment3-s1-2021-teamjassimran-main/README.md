This is the repository for keeping track of work done on assignment 3 in Semester 1, 2021

You can find the starting files inside the folder named 2021s1-assignment3 and its subfolders. Make sure you 'clone' the repository into Eclipse (or other IDE), by importing a project from GitHub - see the instructions from page 7 of the information guide about using Git with Eclipse (found in the 'Course Information' section of Moodle). 

REMEMBER to use your proper GitHub username (and set the correct email address) when you do commits, and don't forget to PUSH the commits or your partner won't see your work.
